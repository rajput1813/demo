import java.math.BigDecimal;

public class Test {
    //find square root of a number up to k decimal places

    public static void main(String[] args) {
        int n=5,k=3;
        double i=1;
        int low = 1;
        int high=n;
        while(low<=high){
            int mid = low + (high-low)/2;
            long  multi = mid*mid;
            if(multi<n){
                low=mid+1;
                i=mid;
            }
            else if(multi>n){
                high=mid-1;
            }
            else{
                i=mid;
                break;
            }


        }

        if(i*i==n){
            System.out.println(i);

        }
        else{
            double j=i;
            double n1= n;
            while(j*j<n1){
                j=j+ Math.pow(10,-k);

            }
            System.out.println();
        }




    }




}
